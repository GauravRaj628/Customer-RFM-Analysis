# Customer RFM Analysis

A structured project workspace for the Customer RFM Analysis data analytics project.

## Folder structure

- `docs/` — project documentation from Steps 1–9.
- `data/STEP_10_Dataset/` — generated synthetic dataset, SQLite database, and validation reports from Step 10.
- `src/generate_data.py` — deterministic dataset-generation script (seed 42).
- `tests/` — reserved for automated tests in later project steps.

## Dataset notes

- All records are synthetic; no real customer personal data is included.
- The dataset package contains 30 customers, 8 segments, 1 analysis run, 200 transaction line items, and 30 customer RFM records (269 planned records total).
- SQLite database: `data/STEP_10_Dataset/app.db`.
- Excel workbook: `data/STEP_10_Dataset/customer_rfm_data.xlsx`.
- Validation details: `data/STEP_10_Dataset/validation_report.txt` and `.json`.

## Python environment

Use Python 3.12 for the project environment. From this project root, create and activate a virtual environment before installing dependencies for the application in later steps.

## Important

The `app.db` file is a generated local database. If the application is later deployed to Streamlit Community Cloud, local SQLite changes may not persist across restarts unless an external persistent storage solution is configured.
