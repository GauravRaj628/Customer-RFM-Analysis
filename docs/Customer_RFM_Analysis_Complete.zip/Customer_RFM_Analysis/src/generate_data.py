#!/usr/bin/env python3
"""Generate deterministic synthetic Customer RFM Analysis data (seed=42)."""
from __future__ import annotations
import hashlib, json, random, sqlite3
from pathlib import Path
from datetime import date, datetime, timedelta
import pandas as pd
import numpy as np

SEED = 42
random.seed(SEED)
rng = np.random.default_rng(SEED)
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

# Fixed reporting window and fictional Indian identities/locations.
PERIOD_START = date(2025, 1, 1)
PERIOD_END = date(2025, 12, 31)
REFERENCE_DATE = date(2026, 1, 1)
FIRST_NAMES = ["Aarav","Vivaan","Aditya","Vihaan","Arjun","Sai","Reyansh","Ayaan","Krishna","Ishaan",
               "Ananya","Diya","Aadhya","Saanvi","Myra","Ira","Anika","Kavya","Meera","Riya",
               "Neha","Pooja","Rahul","Rohan","Kunal","Nisha","Amit","Sneha","Tanya","Dev"]
LAST_NAMES = ["Sharma","Verma","Gupta","Singh","Patel","Kumar","Reddy","Mehta","Joshi","Das",
              "Mishra","Yadav","Nair","Iyer","Chauhan","Malhotra","Bansal","Saxena","Rao","Jain"]
PLACES = ["Ghaziabad","Noida","Delhi","Jaipur","Lucknow","Kanpur","Agra","Indore","Bhopal","Patna",
          "Ranchi","Kolkata","Pune","Mumbai","Hyderabad","Bengaluru","Chennai","Kochi","Ahmedabad","Surat"]
REGIONS = ["North","South","East","West","Central"]
CATEGORIES = ["Electronics","Fashion","Home","Grocery","Beauty","Sports"]
PRODUCTS = [f"SKU-{i:03d}" for i in range(1,31)]

def iso(d): return d.isoformat()
def dt(d, hour=10): return f"{d.isoformat()}T{hour:02d}:30:00"

# 30 synthetic customers; optional values deliberately missing for quality checks.
customers=[]
for i in range(1,31):
    signup = PERIOD_START + timedelta(days=int(rng.integers(0,240)))
    customers.append({
        "customer_id":f"CUST-{i:04d}", "customer_code":f"ABC-C{i:04d}",
        "customer_group":random.choice(["New","Returning","VIP"]),
        "region":REGIONS[(i-1)%5], "signup_date":iso(signup),
        "is_active":1 if i not in (7,19,28) else 0, "created_at":dt(signup,9)
    })
# 2-3% missing values only in nullable columns; preserve required constraints.
customers[4]["customer_group"]=None
customers[16]["region"]=None
customers[22]["signup_date"]=None

segments = [
(1,"Champions","Best recent, frequent and high-spend customers.","0–30 days; R score 4–5","4–5 orders / high frequency","Top monetary quintile",1),
(2,"Loyal","Recent customers with consistently repeat purchases.","0–60 days; R score 3–5","3+ orders","Upper monetary range",2),
(3,"Potential_Loyalist","Recent customers with emerging repeat behaviour.","0–45 days","2–3 orders","Medium monetary range",3),
(4,"New_Customers","Recently active customers with limited purchase history.","0–30 days","1 order","Any spend",4),
(5,"Promising","Moderately recent customers with moderate value.","31–60 days","2+ orders","Medium spend",5),
(6,"At_Risk","Previously engaged customers whose last purchase is ageing.","31–90 days","2+ orders or historically high spend","Medium/high spend",6),
(7,"Cannot_Lose","High-value historical customers needing attention.","31–90 days","3+ orders","High spend",7),
(8,"Hibernating","Long-inactive or low-engagement customers.","More than 90 days","1–2 orders","Low/medium spend",8)
]
segment_rows=[]
for sid,code,desc,rr,fr,mr,rank in segments:
    segment_rows.append(dict(segment_id=sid,segment_code=code,segment_name=code.replace("_"," "),
        segment_description=desc,recency_rule=rr,frequency_rule=fr,monetary_rule=mr,priority_rank=rank))

analysis_run=[dict(run_id=1,source_file_name="customer_rfm_synthetic_data.xlsx",
    source_hash=None,analysis_period_start=iso(PERIOD_START),analysis_period_end=iso(PERIOD_END),
    reference_date=iso(REFERENCE_DATE),currency_code="INR",rules_version="rfm-v1",
    created_at="2026-01-01T09:00:00",run_status="COMPLETED")]

# Build transaction rows: 200 line items across 30 customers.
# Intentional patterns: loyal high-value cohorts; seasonal festive spike;
# high-spend Electronics customers; recent customers and a dormant cohort.
rows=[]
line_id=1
for cid in range(1,31):
    # Deterministic customer archetypes drive discoverable patterns.
    if cid <= 6: n_orders = 7 + (cid % 2)        # champions / loyal
    elif cid <= 12: n_orders = 4 + (cid % 2)    # repeat potential
    elif cid <= 20: n_orders = 2 + (cid % 2)    # moderate
    else: n_orders = 1 + (cid % 2)             # low frequency
    if cid in (7,19,28): n_orders=max(1,n_orders-1)
    # spread dates; selected customers have a recent purchase, others older.
    for order_no in range(1,n_orders+1):
        if cid <= 6:
            day = int(rng.integers(240,365))
        elif cid <= 12:
            day = int(rng.integers(170,355))
        elif cid <= 20:
            day = int(rng.integers(80,320))
        else:
            day = int(rng.integers(5,250))
        if cid in (24,26,29,30): day = int(rng.integers(5,28)) # hibernating
        if cid in (7,19,28): day = int(rng.integers(95,180))
        purchase = PERIOD_START + timedelta(days=day)
        order_id=f"ORD-{cid:03d}-{order_no:02d}"
        # A festive uplift in Oct/Nov for several customers.
        festive = purchase.month in (10,11)
        category = "Electronics" if cid in (1,2,3,4,5,6) and order_no % 2 else random.choice(CATEGORIES)
        quantity = int(rng.integers(1,4))
        base_price = {"Electronics":8500,"Fashion":1400,"Home":2600,"Grocery":450,
                      "Beauty":900,"Sports":1800}[category]
        multiplier = 1.45 if festive else 1.0
        if cid in (1,2,3,4,5,6): multiplier *= 1.35
        unit_price=round(float(rng.uniform(.65,1.45)*base_price*multiplier),2)
        amount=round(quantity*unit_price,2)
        # A few legitimate high-ticket outliers for robust outlier detection.
        if cid==2 and order_no==1: quantity,unit_price,amount=2,79999.00,159998.00
        status="COMPLETED"
        if line_id in (48,126): status="RETURNED"
        if line_id==173: status="CANCELLED"
        valid=1 if status=="COMPLETED" else 0
        reason=None if valid else ("RETURNED_ORDER" if status=="RETURNED" else "CANCELLED_ORDER")
        rows.append(dict(transaction_line_id=line_id,run_id=1,customer_id=f"CUST-{cid:04d}",
            order_id=order_id,purchase_date=iso(purchase),product_id=random.choice(PRODUCTS),
            category=category,quantity=quantity,unit_price=unit_price,transaction_amount=amount,
            order_status=status,is_valid=valid,exclusion_reason=reason))
        line_id+=1
# Trim/pad to exactly 200 lines without breaking customer coverage.
rows=rows[:200]
while len(rows)<200:
    cid=(len(rows)%30)+1
    prior=[r for r in rows if r["customer_id"]==f"CUST-{cid:04d}"]
    if not prior: cid=1; prior=[r for r in rows if r["customer_id"]=="CUST-0001"]
    p=prior[-1].copy()
    p["transaction_line_id"]=len(rows)+1
    p["order_id"]=f"ORD-{cid:03d}-X{len(rows)+1:03d}"
    p["purchase_date"]=iso(PERIOD_START+timedelta(days=250+(len(rows)%100)))
    p["transaction_amount"]=round(p["transaction_amount"]*.85,2)
    p["unit_price"]=round(p["transaction_amount"]/p["quantity"],2)
    rows.append(p)
# Deliberate duplicate business event (new surrogate line id, same customer/order/date/product).
dup=rows[59].copy()
dup["transaction_line_id"]=201
dup["is_valid"]=0
dup["exclusion_reason"]="DUPLICATE_SOURCE_ROW"
rows.append(dup)
# Keep 200 planned rows: replace final line with the marked duplicate, preserving total.
rows=rows[:199]+[dup]
# Nullable optional fields: ~2% missingness.
rows[10]["product_id"]=None
rows[88]["category"]=None

# RFM is calculated only from valid COMPLETED transactions, deduplicated on customer/order.
valid=[r for r in rows if r["is_valid"]==1 and r["order_status"]=="COMPLETED"]
# remove any duplicated business order line for the same customer/order in RFM aggregation
valid_unique={}
for r in valid:
    valid_unique[(r["customer_id"],r["order_id"])]=r
valid=list(valid_unique.values())
by_customer={c["customer_id"]:[] for c in customers}
for r in valid: by_customer[r["customer_id"]].append(r)
# Ensure all 30 customers have at least one valid order in the generated dataset.
for c in customers:
    if not by_customer[c["customer_id"]]:
        # Convert an existing cancelled row for this customer to a completed valid row.
        candidate=next((r for r in rows if r["customer_id"]==c["customer_id"]),None)
        if candidate:
            candidate["order_status"]="COMPLETED"; candidate["is_valid"]=1; candidate["exclusion_reason"]=None
            by_customer[c["customer_id"]]=[candidate]

def quintile_scores(values, reverse=False):
    # Rank-based bins, deterministic for ties and small synthetic samples.
    s=pd.Series(values, dtype=float)
    ranks=s.rank(method="average",ascending=not reverse,pct=True)
    return [max(1,min(5,int(np.ceil(x*5)))) for x in ranks]

customer_ids=[c["customer_id"] for c in customers]
last_dates=[]; freqs=[]; monies=[]
for cid in customer_ids:
    tx=[r for r in valid if r["customer_id"]==cid]
    last_dates.append(max(date.fromisoformat(r["purchase_date"]) for r in tx))
    freqs.append(len(set(r["order_id"] for r in tx)))
    monies.append(round(sum(r["transaction_amount"] for r in tx),2))
recencies=[(REFERENCE_DATE-d).days for d in last_dates]
r_scores=quintile_scores(recencies,reverse=True)
f_scores=quintile_scores(freqs)
m_scores=quintile_scores(monies)
# Segment mapping: mutually exclusive; score-driven and aligned with segment definitions.
rfm=[]
for i,cid in enumerate(customer_ids):
    r,f,m=r_scores[i],f_scores[i],m_scores[i]
    rec=recencies[i]
    if r>=4 and f>=4 and m>=4: sid=1
    elif r>=3 and f>=4: sid=2
    elif r>=4 and f>=2: sid=3
    elif rec<=30 and f==1: sid=4
    elif rec<=60 and f>=2: sid=5
    elif 31<=rec<=90 and m>=4: sid=7
    elif 31<=rec<=90: sid=6
    else: sid=8
    code=f"{r}{f}{m}"
    rfm.append(dict(run_id=1,customer_id=cid,last_purchase_date=iso(last_dates[i]),
        recency_days=rec,frequency_orders=freqs[i],monetary_total=monies[i],
        r_score=r,f_score=f,m_score=m,rfm_code=code,segment_id=sid,
        activity_band="RECENT" if rec<=30 else ("AT_RISK" if rec<=90 else "INACTIVE"),
        is_high_value=1 if sid in (1,2,7) else 0,is_repeat_customer=1 if freqs[i]>=2 else 0,
        rank_by_monetary=0,calculated_at="2026-01-01T09:05:00"))
# Rank descending monetary; unique stable rank.
for rank, rec in enumerate(sorted(rfm,key=lambda x:(-x["monetary_total"],x["customer_id"])),1):
    rec["rank_by_monetary"]=rank

# Hash source fingerprint from deterministic transaction content.
source_hash=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
analysis_run[0]["source_hash"]=source_hash

TABLES={
"customer_master":pd.DataFrame(customers),
"segment_master":pd.DataFrame(segment_rows),
"analysis_run":pd.DataFrame(analysis_run),
"transaction_fact":pd.DataFrame(rows),
"customer_rfm_fact":pd.DataFrame(rfm)
}
# Explicit SQLite schema based on the Step 8 data dictionary.
DDL = """
PRAGMA foreign_keys = ON;
CREATE TABLE customer_master (
 customer_id TEXT PRIMARY KEY, customer_code TEXT NOT NULL UNIQUE,
 customer_group TEXT, region TEXT, signup_date TEXT,
 is_active INTEGER NOT NULL CHECK(is_active IN (0,1)),
 created_at TEXT NOT NULL
);
CREATE TABLE segment_master (
 segment_id INTEGER PRIMARY KEY, segment_code TEXT NOT NULL UNIQUE,
 segment_name TEXT NOT NULL UNIQUE, segment_description TEXT NOT NULL,
 recency_rule TEXT NOT NULL, frequency_rule TEXT NOT NULL,
 monetary_rule TEXT NOT NULL, priority_rank INTEGER NOT NULL UNIQUE CHECK(priority_rank BETWEEN 1 AND 8)
);
CREATE TABLE analysis_run (
 run_id INTEGER PRIMARY KEY CHECK(run_id > 0), source_file_name TEXT NOT NULL,
 source_hash TEXT UNIQUE, analysis_period_start TEXT NOT NULL,
 analysis_period_end TEXT NOT NULL, reference_date TEXT NOT NULL,
 currency_code TEXT NOT NULL CHECK(currency_code='INR'),
 rules_version TEXT NOT NULL, created_at TEXT NOT NULL,
 run_status TEXT NOT NULL CHECK(run_status IN ('CREATED','VALIDATED','COMPLETED','FAILED'))
);
CREATE TABLE transaction_fact (
 transaction_line_id INTEGER PRIMARY KEY CHECK(transaction_line_id > 0),
 run_id INTEGER NOT NULL REFERENCES analysis_run(run_id),
 customer_id TEXT NOT NULL REFERENCES customer_master(customer_id),
 order_id TEXT NOT NULL, purchase_date TEXT NOT NULL, product_id TEXT, category TEXT,
 quantity INTEGER NOT NULL CHECK(quantity > 0), unit_price REAL NOT NULL CHECK(unit_price >= 0),
 transaction_amount REAL NOT NULL CHECK(transaction_amount >= 0),
 order_status TEXT NOT NULL CHECK(order_status IN ('COMPLETED','RETURNED','CANCELLED')),
 is_valid INTEGER NOT NULL CHECK(is_valid IN (0,1)), exclusion_reason TEXT
);
CREATE TABLE customer_rfm_fact (
 run_id INTEGER NOT NULL REFERENCES analysis_run(run_id),
 customer_id TEXT NOT NULL REFERENCES customer_master(customer_id),
 last_purchase_date TEXT NOT NULL, recency_days INTEGER NOT NULL CHECK(recency_days >= 0),
 frequency_orders INTEGER NOT NULL CHECK(frequency_orders >= 1),
 monetary_total REAL NOT NULL CHECK(monetary_total >= 0),
 r_score INTEGER NOT NULL CHECK(r_score BETWEEN 1 AND 5),
 f_score INTEGER NOT NULL CHECK(f_score BETWEEN 1 AND 5),
 m_score INTEGER NOT NULL CHECK(m_score BETWEEN 1 AND 5),
 rfm_code TEXT NOT NULL CHECK(length(rfm_code)=3),
 segment_id INTEGER NOT NULL REFERENCES segment_master(segment_id),
 activity_band TEXT NOT NULL CHECK(activity_band IN ('RECENT','AT_RISK','INACTIVE')),
 is_high_value INTEGER NOT NULL CHECK(is_high_value IN (0,1)),
 is_repeat_customer INTEGER NOT NULL CHECK(is_repeat_customer IN (0,1)),
 rank_by_monetary INTEGER NOT NULL CHECK(rank_by_monetary >= 1),
 calculated_at TEXT NOT NULL,
 PRIMARY KEY(run_id, customer_id)
);
CREATE INDEX idx_tx_customer_date ON transaction_fact(customer_id,purchase_date);
CREATE INDEX idx_tx_run_status ON transaction_fact(run_id,order_status,is_valid);
CREATE INDEX idx_rfm_segment ON customer_rfm_fact(run_id,segment_id);
"""
# Joined analysis view exactly 36 columns as Step 8 specification.
VIEW = """
CREATE VIEW vw_customer_rfm_analysis AS
WITH segment_stats AS (
 SELECT r.run_id,r.segment_id,COUNT(*) AS customer_count_in_segment,
        SUM(r.monetary_total) AS revenue_total
 FROM customer_rfm_fact r GROUP BY r.run_id,r.segment_id
), tx_stats AS (
 SELECT run_id,customer_id,COUNT(DISTINCT CASE WHEN is_valid=1 AND order_status='COMPLETED' THEN order_id END) AS valid_order_count,
        SUM(CASE WHEN is_valid=1 AND order_status='COMPLETED' THEN 1 ELSE 0 END) AS valid_transaction_rows
 FROM transaction_fact GROUP BY run_id,customer_id
), run_revenue AS (
 SELECT run_id,SUM(CASE WHEN is_valid=1 AND order_status='COMPLETED' THEN transaction_amount ELSE 0 END) AS total_revenue
 FROM transaction_fact GROUP BY run_id
)
SELECT r.run_id,a.source_file_name,a.analysis_period_start,a.analysis_period_end,a.reference_date,
 a.currency_code,c.customer_id,c.customer_code,c.customer_group,c.region,c.signup_date,
 c.is_active AS customer_is_active,r.last_purchase_date,r.recency_days,r.frequency_orders,r.monetary_total,
 r.r_score,r.f_score,r.m_score,r.rfm_code,s.segment_code,s.segment_name,s.segment_description,
 r.activity_band,r.is_high_value,r.is_repeat_customer,r.rank_by_monetary,s.priority_rank AS segment_priority_rank,
 COALESCE(t.valid_order_count,0) AS valid_order_count,COALESCE(t.valid_transaction_rows,0) AS valid_transaction_rows,
 COALESCE(ss.revenue_total,0) AS revenue_total,
 CASE WHEN rr.total_revenue>0 THEN 100.0*ss.revenue_total/rr.total_revenue ELSE 0 END AS revenue_share_pct,
 ss.customer_count_in_segment,
 100.0*ss.customer_count_in_segment/(SELECT COUNT(*) FROM customer_rfm_fact x WHERE x.run_id=r.run_id) AS customer_share_pct,
 CASE WHEN ss.customer_count_in_segment>0 THEN ss.revenue_total/ss.customer_count_in_segment ELSE 0 END AS segment_revenue_per_customer,
 a.created_at AS analysis_created_at
FROM customer_rfm_fact r
JOIN analysis_run a ON a.run_id=r.run_id
JOIN customer_master c ON c.customer_id=r.customer_id
JOIN segment_master s ON s.segment_id=r.segment_id
LEFT JOIN segment_stats ss ON ss.run_id=r.run_id AND ss.segment_id=r.segment_id
LEFT JOIN tx_stats t ON t.run_id=r.run_id AND t.customer_id=r.customer_id
LEFT JOIN run_revenue rr ON rr.run_id=r.run_id;
"""

# Write database, with foreign keys enabled for the connection and schema.
db=DATA/"app.db"
if db.exists(): db.unlink()
con=sqlite3.connect(db)
con.execute("PRAGMA foreign_keys=ON")
con.executescript(DDL)
for name,df in TABLES.items():
    df.to_sql(name,con,if_exists="append",index=False)
con.executescript(VIEW)
con.commit()
fk_rows=con.execute("PRAGMA foreign_key_check").fetchall()
view_cols=[x[1] for x in con.execute("PRAGMA table_info(vw_customer_rfm_analysis)").fetchall()]
view_count=con.execute("SELECT COUNT(*) FROM vw_customer_rfm_analysis").fetchone()[0]
counts={t:con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in TABLES}
# Range and business-rule validation.
checks={
"foreign_key_check":"PASS" if not fk_rows else f"FAIL: {fk_rows}",
"view_column_count":"PASS" if len(view_cols)==36 else f"FAIL: {len(view_cols)}",
"view_row_count":"PASS" if view_count==30 else f"FAIL: {view_count}",
"recency_nonnegative":"PASS" if con.execute("SELECT COUNT(*) FROM customer_rfm_fact WHERE recency_days<0").fetchone()[0]==0 else "FAIL",
"rfm_scores_1_to_5":"PASS" if con.execute("SELECT COUNT(*) FROM customer_rfm_fact WHERE r_score NOT BETWEEN 1 AND 5 OR f_score NOT BETWEEN 1 AND 5 OR m_score NOT BETWEEN 1 AND 5").fetchone()[0]==0 else "FAIL",
"activity_band_valid":"PASS" if con.execute("SELECT COUNT(*) FROM customer_rfm_fact WHERE activity_band NOT IN ('RECENT','AT_RISK','INACTIVE')").fetchone()[0]==0 else "FAIL",
"segment_fk_valid":"PASS" if con.execute("SELECT COUNT(*) FROM customer_rfm_fact r LEFT JOIN segment_master s USING(segment_id) WHERE s.segment_id IS NULL").fetchone()[0]==0 else "FAIL",
"planned_row_counts":"PASS" if counts=={"customer_master":30,"segment_master":8,"analysis_run":1,"transaction_fact":200,"customer_rfm_fact":30} else f"FAIL: {counts}"
}
con.close()

# CSV exports and workbook (one sheet per table).
for name,df in TABLES.items():
    df.to_csv(DATA/f"{name}.csv",index=False,encoding="utf-8-sig")
xlsx=DATA/"customer_rfm_data.xlsx"
with pd.ExcelWriter(xlsx,engine="openpyxl") as writer:
    for name,df in TABLES.items():
        df.to_excel(writer,sheet_name=name,index=False)
    # A compact data dictionary / quality issue register for workbook users.
    pd.DataFrame([
      ["Missing optional values","customer_master.customer_group (1), region (1), signup_date (1); transaction_fact.product_id (1), category (1)","Nullable columns only; approximately 2% of cells in selected optional fields."],
      ["Duplicate source event","transaction_fact row 200 duplicates business event of row 60; marked is_valid=0","Use customer_id + order_id + purchase_date + product_id to detect; surrogate line ID remains unique."],
      ["Outliers","One high-value Electronics order of INR 159,998; several upper-tail purchases","Inspect with IQR/percentile methods; values remain plausible for premium electronics."],
      ["Returned/cancelled records","Two RETURNED and one CANCELLED rows","Excluded from core RFM; inspect status handling."]
    ],columns=["Issue","Location","Handling"]).to_excel(writer,sheet_name="Quality_Issues",index=False)

report={
"project":"Customer RFM Analysis","seed":SEED,"currency":"INR",
"planned_rows": {"customer_master":30,"segment_master":8,"analysis_run":1,"transaction_fact":200,"customer_rfm_fact":30},
"actual_rows":counts,"joined_view":"vw_customer_rfm_analysis","joined_view_columns":len(view_cols),
"joined_view_rows":view_count,"validation":checks,"foreign_key_violations":fk_rows,
"quality_issues":[
"Optional fields intentionally missing: customer_group (1), region (1), signup_date (1), product_id (1), category (1).",
"One duplicate source event is present as transaction_fact transaction_line_id=200 and marked invalid with DUPLICATE_SOURCE_ROW.",
"One high-ticket Electronics purchase (INR 159,998) is included as a plausible statistical outlier.",
"Two returned and one cancelled transaction rows are excluded from valid RFM calculations."
],
"analysis_patterns":[
"Customers CUST-0001 to CUST-0006 have comparatively high order frequency and spend, creating a loyal/high-value cohort.",
"October-November purchases have a seasonal uplift in several customers' order values.",
"Electronics transactions contribute disproportionately to the upper monetary tail.",
"Customers CUST-0024, CUST-0026, CUST-0029 and CUST-0030 have older last-purchase dates and should appear in the inactive/hibernating group."
],
"files":["customer_rfm_data.xlsx","customer_master.csv","segment_master.csv","analysis_run.csv","transaction_fact.csv","customer_rfm_fact.csv","app.db","validation_report.json"]
}
(DATA/"validation_report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps(report,indent=2))
